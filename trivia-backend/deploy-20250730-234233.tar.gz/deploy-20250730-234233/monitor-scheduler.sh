#!/bin/bash

# Monitoring script for Sunday Night Scheduler
LOG_FILE="/var/log/trivia-scheduler.log"
SCHEDULER_DIR="/var/www/trivia-backend"

echo "📊 Sunday Night Scheduler Status"
echo "================================"

# Check if cron job exists
echo "🕐 Cron Job Status:"
if crontab -l 2>/dev/null | grep -q "sunday-night-scheduler.js"; then
    echo "  ✅ Cron job is configured"
    crontab -l | grep "sunday-night-scheduler.js"
else
    echo "  ❌ Cron job not found"
fi

echo ""

# Check recent executions
echo "📋 Recent Executions (last 10 lines):"
if [ -f "$LOG_FILE" ]; then
    tail -10 "$LOG_FILE"
else
    echo "  ❌ Log file not found at $LOG_FILE"
fi

echo ""

# Check if scheduler can run
echo "🧪 Test Run:"
cd "$SCHEDULER_DIR" || exit 1
if node sunday-night-scheduler.js --dry-run; then
    echo "  ✅ Scheduler test passed"
else
    echo "  ❌ Scheduler test failed"
fi

echo ""
echo "📁 Useful paths:"
echo "  Scheduler directory: $SCHEDULER_DIR"
echo "  Log file: $LOG_FILE"
echo "  Edit cron: crontab -e"
