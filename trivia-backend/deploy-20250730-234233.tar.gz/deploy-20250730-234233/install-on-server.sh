#!/bin/bash

# Server-side installation script
set -e

INSTALL_DIR="/var/www/trivia-backend"
LOG_DIR="/var/log"
BACKUP_DIR="/backups"

echo "🔧 Installing Sunday Night Scheduler on production server..."

# Create directories
sudo mkdir -p "$INSTALL_DIR"
sudo mkdir -p "$LOG_DIR"
sudo mkdir -p "$BACKUP_DIR"

# Copy files (assuming they're in current directory)
echo "📁 Copying files to $INSTALL_DIR..."
sudo cp -r . "$INSTALL_DIR/"
cd "$INSTALL_DIR"

# Set permissions
sudo chown -R www-data:www-data "$INSTALL_DIR"
sudo chmod +x setup-cron.sh
sudo chmod +x sunday-night-scheduler.js

# Install Node.js dependencies
echo "📦 Installing dependencies..."
if command -v pnpm &> /dev/null; then
    sudo -u www-data pnpm install --prod
elif command -v npm &> /dev/null; then
    sudo -u www-data npm install --only=production
else
    echo "❌ Neither pnpm nor npm found. Please install Node.js package manager."
    exit 1
fi

# Check if .env exists
if [ ! -f ".env" ]; then
    echo "⚠️  WARNING: .env file not found!"
    echo "Please create .env file with the following variables:"
    echo "SUPABASE_URL=your_supabase_url"
    echo "SUPABASE_SERVICE_ROLE_KEY=your_service_role_key"
    echo ""
    echo "You can use .env.example as a template if available."
    exit 1
fi

# Test the scheduler
echo "🧪 Testing scheduler..."
if node sunday-night-scheduler.js --dry-run; then
    echo "✅ Scheduler test passed!"
else
    echo "❌ Scheduler test failed. Please check configuration."
    exit 1
fi

echo "✅ Installation complete!"
echo ""
echo "Next steps:"
echo "1. Run: sudo ./setup-cron.sh"
echo "2. Monitor logs: tail -f /var/log/trivia-scheduler.log"
echo "3. Test manually: node sunday-night-scheduler.js"
