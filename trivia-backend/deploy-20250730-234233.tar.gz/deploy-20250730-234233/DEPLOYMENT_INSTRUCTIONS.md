# Sunday Night Scheduler - Production Deployment Instructions

## 📋 Pre-Deployment Checklist

### On Production Server
1. **Ensure Node.js is installed** (version 18+)
   ```bash
   node --version
   npm --version  # or pnpm --version
   ```

2. **Ensure required directories exist**
   ```bash
   sudo mkdir -p /var/www/trivia-backend
   sudo mkdir -p /var/log
   sudo mkdir -p /backups
   ```

3. **Set up environment variables**
   Create `/var/www/trivia-backend/.env` with:
   ```bash
   SUPABASE_URL=https://your-project.supabase.co
   SUPABASE_SERVICE_ROLE_KEY=your_service_role_key_here
   ```

## 🚀 Deployment Steps

### Step 1: Upload Files
Upload this entire directory to your production server:
```bash
# From your local machine
scp -r deploy-* user@your-server:/tmp/scheduler-deploy
```

### Step 2: Install on Server
```bash
# On production server
cd /tmp/scheduler-deploy
sudo ./install-on-server.sh
```

### Step 3: Set Up Cron Job
```bash
cd /var/www/trivia-backend
sudo ./setup-cron-production.sh
```

### Step 4: Verify Installation
```bash
# Test the scheduler
cd /var/www/trivia-backend
node sunday-night-scheduler.js --dry-run

# Check cron job
crontab -l | grep scheduler

# Monitor logs
tail -f /var/log/trivia-scheduler.log
```

## 📊 Monitoring

### Check Status
```bash
cd /var/www/trivia-backend
./monitor-scheduler.sh
```

### View Logs
```bash
# Recent logs
tail -20 /var/log/trivia-scheduler.log

# Follow logs in real-time
tail -f /var/log/trivia-scheduler.log

# Search for errors
grep -i error /var/log/trivia-scheduler.log
```

### Manual Testing
```bash
cd /var/www/trivia-backend

# Dry run (safe test)
node sunday-night-scheduler.js --dry-run

# Actual run (creates real data)
node sunday-night-scheduler.js
```

## 🔧 Troubleshooting

### Common Issues

1. **Permission Errors**
   ```bash
   sudo chown -R www-data:www-data /var/www/trivia-backend
   sudo chmod +x /var/www/trivia-backend/sunday-night-scheduler.js
   ```

2. **Environment Variables Not Found**
   - Check `/var/www/trivia-backend/.env` exists
   - Verify Supabase credentials are correct
   - Test database connection

3. **Cron Job Not Running**
   ```bash
   # Check cron service
   sudo systemctl status cron
   
   # Check system logs
   grep CRON /var/log/syslog
   ```

4. **Node.js Dependencies**
   ```bash
   cd /var/www/trivia-backend
   npm install --only=production  # or pnpm install --prod
   ```

## ⚠️ Important Notes

- **The cron job runs every Sunday at 10 PM (22:00)**
- **Logs are written to `/var/log/trivia-scheduler.log`**
- **Always test with `--dry-run` first**
- **Monitor the first few runs to ensure success**
- **Set up log rotation to prevent disk space issues**

## 📞 Emergency Procedures

### If Scheduler Fails
1. Check logs: `tail -50 /var/log/trivia-scheduler.log`
2. Test manually: `node sunday-night-scheduler.js --dry-run`
3. Check database connectivity
4. Verify environment variables

### If Cron Job Stops Working
1. Check cron service: `sudo systemctl status cron`
2. Verify cron job exists: `crontab -l | grep scheduler`
3. Re-run setup: `./setup-cron-production.sh`

---

**Deployment Date**: Wed Jul 30 23:42:33 CDT 2025
**Deployed By**: Production Deployment Script
**Next Scheduled Run**: Next Sunday at 10 PM
