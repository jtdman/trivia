#!/bin/bash

# Production Cron Setup for Sunday Night Scheduler
set -e

PROJECT_DIR="/var/www/trivia-backend"
NODE_PATH="$(which node)"
LOG_FILE="/var/log/trivia-scheduler.log"

# Ensure we're in the right directory
cd "$PROJECT_DIR" || exit 1

echo "🔧 Setting up Production Sunday Night Event Scheduler..."
echo "📁 Project directory: $PROJECT_DIR"
echo "🟢 Node path: $NODE_PATH"
echo "📝 Log file: $LOG_FILE"
echo "⏰ Schedule: Every Sunday at 10 PM (22:00)"

# Create log file with proper permissions
sudo touch "$LOG_FILE"
sudo chown www-data:www-data "$LOG_FILE"

# Build the cron command
CRON_COMMAND="0 22 * * SUN cd $PROJECT_DIR && $NODE_PATH sunday-night-scheduler.js >> $LOG_FILE 2>&1"

echo ""
echo "🕐 Installing cron job..."

# Remove any existing scheduler jobs and add the new one
(crontab -l 2>/dev/null | grep -v "sunday-night-scheduler.js"; echo "$CRON_COMMAND") | crontab -

echo "✅ Cron job installed successfully!"
echo ""
echo "📋 Current scheduler cron jobs:"
crontab -l | grep "sunday-night-scheduler.js" || echo "   (No matching entries found)"

echo ""
echo "🧪 Testing scheduler..."
if node sunday-night-scheduler.js --dry-run; then
    echo "✅ Scheduler test passed!"
else
    echo "❌ Scheduler test failed. Please check configuration."
    exit 1
fi

echo ""
echo "📊 Monitoring commands:"
echo "  View logs: tail -f $LOG_FILE"
echo "  Test run: cd $PROJECT_DIR && node sunday-night-scheduler.js --dry-run"
echo "  Manual run: cd $PROJECT_DIR && node sunday-night-scheduler.js"
echo "  Monitor status: ./monitor-scheduler.sh"
echo ""
echo "🗑️  To remove cron job:"
echo "  crontab -e  # Then delete the line containing 'sunday-night-scheduler.js'"

echo ""
echo "🎉 Production scheduler setup complete!"
